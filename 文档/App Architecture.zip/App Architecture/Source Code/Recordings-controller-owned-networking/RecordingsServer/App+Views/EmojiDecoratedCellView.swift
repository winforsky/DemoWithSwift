import Cocoa

class EmojiDecoratedCellView: NSTableCellView {
	@IBOutlet var emoji: NSTextField!
}
