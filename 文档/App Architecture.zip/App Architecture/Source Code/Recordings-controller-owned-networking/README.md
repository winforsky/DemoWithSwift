## Controller-Owned Networking Sample Project

Open the workspace and launch the macOS server and the iOS client. Once you hit the "Start Server" button in the Mac app, it will be detected via Bonjour and shown in the list of servers in the iOS app. Select the server and use the app as normal — all changes will committed to and loaded from the server.