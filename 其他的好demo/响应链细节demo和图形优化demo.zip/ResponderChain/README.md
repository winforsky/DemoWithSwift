## ResponderChain
- [iOS响应者链彻底掌握](https://segmentfault.com/a/1190000015060603)