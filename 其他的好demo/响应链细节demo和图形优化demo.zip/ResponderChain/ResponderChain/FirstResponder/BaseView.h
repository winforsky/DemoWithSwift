//
//  BaseView.h
//  ResponderChain
//
//  Created by dangercheng on 2018/5/24.
//  Copyright © 2018年 DandJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseView : UIView

@end

@interface RootView : BaseView
@end

@interface View1 : BaseView
@end

@interface View2 : BaseView
@end

@interface View3 : BaseView
@end

@interface View4 : BaseView
@end

@interface View5 : BaseView
@end

@interface CircleView : BaseView
@end
