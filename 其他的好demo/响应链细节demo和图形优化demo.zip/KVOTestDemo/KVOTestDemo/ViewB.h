//
//  ViewB.h
//  KVOTestDemo
//
//  Created by dangercheng on 2018/11/1.
//  Copyright © 2018 DandJ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewB : UIView
@property (nonatomic, assign) NSInteger countValue;
- (void)increaseValue;
@end

NS_ASSUME_NONNULL_END
